/* ==========================================
   RÊVE — app.js
   Full streaming platform logic
   TMDB API + Smart Player + All Features
   ========================================== */

'use strict';

// ===== CONFIG =====
const API_KEY  = 'da87358fe15e91315b13c0b1f439b8fd';
const API_TOKEN = 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJkYTg3MzU4ZmUxNWU5MTMxNWIxM2MwYjFmNDM5YjhmZCIsIm5iZiI6MTc3NzI1NzU2My41MjcsInN1YiI6IjY5ZWVjYzViNDk4Y2YxNDA2NjAyOTkzMCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.TQ6XojRk4ejK4DawXrMJ0tH-6enYdAkD-3wuqUGrcSs';
const BASE     = 'https://api.themoviedb.org/3';
const IMG      = 'https://image.tmdb.org/t/p/';
const HEADERS  = { 'Authorization': `Bearer ${API_TOKEN}`, 'accept': 'application/json' };

// Player sources — smart fallback order
const SOURCES = [
  { id: 'vidsrc',    label: 'VidSrc',     movie: id => `https://vidsrc.xyz/embed/movie/${id}`,  tv: (id,s,e) => `https://vidsrc.xyz/embed/tv/${id}/${s}/${e}` },
  { id: 'superembed', label: 'SuperEmbed', movie: id => `https://multiembed.mov/?video_id=${id}&tmdb=1`, tv: (id,s,e) => `https://multiembed.mov/?video_id=${id}&tmdb=1&s=${s}&e=${e}` },
  { id: 'vidsrcto',  label: 'VidSrc.to',  movie: id => `https://vidsrc.to/embed/movie/${id}`,  tv: (id,s,e) => `https://vidsrc.to/embed/tv/${id}/${s}/${e}` },
  { id: 'smashystream', label: 'SmashyStream', movie: id => `https://player.smashy.stream/movie/${id}`, tv: (id,s,e) => `https://player.smashy.stream/tv/${id}?s=${s}&e=${e}` },
];

// ===== STATE =====
let state = {
  currentPage: 'home',
  prevPage: null,
  heroItem: null,
  heroType: 'movie',
  currentItem: null,
  currentType: 'movie',
  activeSource: 0,
  activeSeason: 1,
  activeEpisode: 1,
  moviePage: 1, movieCat: 'popular', movieGenre: '', movieYear: '',
  seriesPage: 1, seriesCat: 'popular', seriesGenre: '',
  kidsPage: 1,
  searchTimer: null,
  lockTaps: 0, lockTimer: null,
  childLocked: false,
  genres: { movie: {}, tv: {} },
};

// ===== INIT =====
window.addEventListener('DOMContentLoaded', () => {
  runLoadingScreen();
  window.addEventListener('scroll', handleScroll);
});

function runLoadingScreen() {
  const bar = document.getElementById('loadingBar');
  const pct = document.getElementById('loadingPercent');
  const screen = document.getElementById('loadingScreen');
  let p = 0;
  const iv = setInterval(() => {
    p += Math.random() * 18;
    if (p >= 100) { p = 100; clearInterval(iv); }
    bar.style.width = p + '%';
    if (pct) pct.textContent = Math.round(p) + '%';
    if (p >= 100) {
      setTimeout(() => {
        screen.classList.add('done');
        initApp();
      }, 400);
    }
  }, 120);
}

async function initApp() {
  await fetchGenres();
  await Promise.all([
    loadHomeRows(),
    populateGenreSelects(),
    loadYearFilter(),
  ]);
}

// ===== GENRES =====
async function fetchGenres() {
  try {
    const [mv, tv] = await Promise.all([
      fetchJSON(`${BASE}/genre/movie/list?language=ar`),
      fetchJSON(`${BASE}/genre/tv/list?language=ar`),
    ]);
    (mv.genres || []).forEach(g => state.genres.movie[g.id] = g.name);
    (tv.genres || []).forEach(g => state.genres.tv[g.id] = g.name);
  } catch(e) {}
}

function populateGenreSelects() {
  const mg = document.getElementById('moviesGenre');
  const sg = document.getElementById('seriesGenre');
  Object.entries(state.genres.movie).forEach(([id, name]) => {
    const o = new Option(name, id);
    mg && mg.appendChild(o);
  });
  Object.entries(state.genres.tv).forEach(([id, name]) => {
    const o = new Option(name, id);
    sg && sg.appendChild(o);
  });
}

function loadYearFilter() {
  const sy = document.getElementById('moviesYear');
  if (!sy) return;
  const cur = new Date().getFullYear();
  for (let y = cur; y >= 1970; y--) {
    sy.appendChild(new Option(y, y));
  }
}

// ===== HOME ROWS =====
async function loadHomeRows() {
  const container = document.getElementById('homeRows');
  container.innerHTML = '';

  const rowDefs = [
    { title: '🔥 الأكثر شعبية حالاً', url: `${BASE}/movie/popular?language=ar&page=1`, type: 'movie', hero: true },
    { title: '⭐ الأعلى تقييماً على الإطلاق', url: `${BASE}/movie/top_rated?language=ar&page=1`, type: 'movie' },
    { title: '📺 مسلسلات رائجة', url: `${BASE}/tv/popular?language=ar&page=1`, type: 'tv' },
    { title: '🎬 يُعرض الآن في السينما', url: `${BASE}/movie/now_playing?language=ar&page=1`, type: 'movie' },
    { title: '🏆 أعلى تقييماً — مسلسلات', url: `${BASE}/tv/top_rated?language=ar&page=1`, type: 'tv' },
    { title: '🌙 أفلام دراما', url: `${BASE}/discover/movie?language=ar&with_genres=18&sort_by=popularity.desc`, type: 'movie' },
    { title: '💥 أكشن وإثارة', url: `${BASE}/discover/movie?language=ar&with_genres=28&sort_by=popularity.desc`, type: 'movie' },
    { title: '👨‍👩‍👧 للعائلة', url: `${BASE}/discover/movie?language=ar&with_genres=10751&sort_by=popularity.desc`, type: 'movie' },
    { title: '🚀 خيال علمي', url: `${BASE}/discover/movie?language=ar&with_genres=878&sort_by=popularity.desc`, type: 'movie' },
    { title: '🕵️ جريمة وغموض', url: `${BASE}/discover/movie?language=ar&with_genres=80&sort_by=popularity.desc`, type: 'movie' },
    { title: '🎨 أنيماشن', url: `${BASE}/discover/movie?language=ar&with_genres=16&sort_by=popularity.desc`, type: 'movie' },
    { title: '💕 رومانسي', url: `${BASE}/discover/movie?language=ar&with_genres=10749&sort_by=popularity.desc`, type: 'movie' },
    { title: '🎭 كوميدي', url: `${BASE}/discover/movie?language=ar&with_genres=35&sort_by=popularity.desc`, type: 'movie' },
    { title: '🌟 قريباً', url: `${BASE}/movie/upcoming?language=ar&page=1`, type: 'movie' },
    { title: '📡 يُبث الآن', url: `${BASE}/tv/on_the_air?language=ar&page=1`, type: 'tv' },
    { title: '🇫🇷 أفلام أوروبية مميزة', url: `${BASE}/discover/movie?language=ar&with_original_language=fr|it|de|es&sort_by=vote_average.desc&vote_count.gte=500`, type: 'movie' },
    { title: '🎬 كلاسيكيات السينما', url: `${BASE}/discover/movie?language=ar&primary_release_date.lte=1990-01-01&sort_by=vote_average.desc&vote_count.gte=1000`, type: 'movie' },
    { title: '📺 مسلسلات أمريكية', url: `${BASE}/discover/tv?language=ar&with_original_language=en&sort_by=popularity.desc`, type: 'tv' },
    { title: '🌏 أنيمي ياباني', url: `${BASE}/discover/tv?language=ar&with_original_language=ja&with_genres=16&sort_by=popularity.desc`, type: 'tv' },
    { title: '🏅 الفائزون بالجوائز', url: `${BASE}/discover/movie?language=ar&sort_by=vote_average.desc&vote_count.gte=2000`, type: 'movie' },
  ];

  // Load hero first
  const heroRow = rowDefs.find(r => r.hero);
  if (heroRow) {
    const data = await fetchJSON(heroRow.url);
    if (data?.results?.length) setupHero(data.results, heroRow.type);
  }

  // Load kids grid
  loadKidsGrid();

  // Render rows
  for (let i = 0; i < rowDefs.length; i++) {
    const rd = rowDefs[i];
    const rowEl = document.createElement('div');
    rowEl.className = 'content-row';
    rowEl.innerHTML = `
      <div class="row-header">
        <div class="row-title">${rd.title}</div>
        <div class="row-see-all" onclick="seeAll('${rd.url}','${rd.title}','${rd.type}')">عرض الكل ›</div>
      </div>
      <div class="cards-strip" id="row-${i}"></div>
    `;
    container.appendChild(rowEl);

    fetchJSON(rd.url).then(data => {
      renderCards(document.getElementById(`row-${i}`), data?.results || [], rd.type, true);
    }).catch(() => {});

    if (i % 5 === 0) await sleep(50);
  }
}

// ===== HERO =====
function setupHero(items, type) {
  const item = items[Math.floor(Math.random() * Math.min(5, items.length))];
  if (!item) return;
  state.heroItem = item;
  state.heroType = type;

  const bg = document.getElementById('heroBg');
  const title = document.getElementById('heroTitle');
  const desc = document.getElementById('heroDesc');
  const meta = document.getElementById('heroMeta');
  const badge = document.getElementById('heroBadge');
  const poster = document.getElementById('heroPoster');

  const backdrop = item.backdrop_path ? `${IMG}original${item.backdrop_path}` : '';
  const posterPath = item.poster_path ? `${IMG}w342${item.poster_path}` : '';
  const name = item.title || item.name || 'بدون عنوان';
  const rating = item.vote_average?.toFixed(1);
  const year = (item.release_date || item.first_air_date || '').slice(0, 4);

  if (backdrop) bg.style.backgroundImage = `url(${backdrop})`;
  title.textContent = name;
  desc.textContent = item.overview || 'اضغط للمشاهدة الآن على RÊVE';
  badge.textContent = type === 'movie' ? '🎬 فيلم' : '📺 مسلسل';
  meta.innerHTML = `
    <span class="rating">⭐ ${rating}</span>
    <span class="sep">·</span>
    <span>${year}</span>
    <span class="sep">·</span>
    <span>${type === 'movie' ? 'فيلم' : 'مسلسل'}</span>
  `;
  if (posterPath) {
    poster.style.backgroundImage = `url(${posterPath})`;
    poster.style.display = 'block';
  }

  // Auto-rotate hero every 12s
  let idx = 0;
  setInterval(() => {
    idx = (idx + 1) % Math.min(5, items.length);
    const it = items[idx];
    if (it?.backdrop_path) {
      bg.style.backgroundImage = `url(${IMG}original${it.backdrop_path})`;
      document.getElementById('heroTitle').textContent = it.title || it.name;
      document.getElementById('heroDesc').textContent = it.overview || '';
      state.heroItem = it;
    }
  }, 12000);
}

function playFromHero() {
  if (state.heroItem) openPlayer(state.heroItem, state.heroType);
}
function infoFromHero() {
  if (state.heroItem) openDetail(state.heroItem, state.heroType);
}

// ===== MOOD FILTER =====
function moodClick(el, genre) {
  document.querySelectorAll('.mood').forEach(m => m.classList.remove('active'));
  el.classList.add('active');
  filterByMoodGenre(genre);
}

async function filterByMoodGenre(genre) {
  const container = document.getElementById('homeRows');
  container.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:200px"><div class="pl-spinner"></div></div>';

  let url;
  if (!genre) {
    await loadHomeRows();
    return;
  }
  url = `${BASE}/discover/movie?language=ar&with_genres=${genre}&sort_by=popularity.desc&page=1`;
  const url2 = `${BASE}/discover/tv?language=ar&with_genres=${genre}&sort_by=popularity.desc&page=1`;

  container.innerHTML = '';

  const [mv, tv] = await Promise.all([fetchJSON(url), fetchJSON(url2)]);

  const rows = [
    { title: `🎬 أفلام — ${genreName(genre,'movie')}`, items: mv?.results || [], type: 'movie' },
    { title: `📺 مسلسلات — ${genreName(genre,'tv')}`, items: tv?.results || [], type: 'tv' },
  ];

  rows.forEach((rd, i) => {
    if (!rd.items.length) return;
    const rowEl = document.createElement('div');
    rowEl.className = 'content-row';
    rowEl.innerHTML = `
      <div class="row-header">
        <div class="row-title">${rd.title}</div>
      </div>
      <div class="cards-strip" id="moodrow-${i}"></div>
    `;
    container.appendChild(rowEl);
    // Multiple pages
    for (let p = 1; p <= 4; p++) {
      const pUrl = rd.type === 'movie'
        ? `${BASE}/discover/movie?language=ar&with_genres=${genre}&sort_by=popularity.desc&page=${p}`
        : `${BASE}/discover/tv?language=ar&with_genres=${genre}&sort_by=popularity.desc&page=${p}`;
      fetchJSON(pUrl).then(data => {
        renderCards(document.getElementById(`moodrow-${i}`), data?.results || [], rd.type, true);
      }).catch(() => {});
    }
  });
}

function genreName(id, type) {
  return state.genres[type === 'movie' ? 'movie' : 'tv'][id] || '';
}

// ===== CARDS =====
function renderCards(container, items, type, append = false) {
  if (!container) return;
  if (!append) container.innerHTML = '';
  items.forEach(item => {
    const el = createCard(item, type);
    container.appendChild(el);
  });
}

function createCard(item, type) {
  const name = item.title || item.name || 'بدون عنوان';
  const poster = item.poster_path ? `${IMG}w342${item.poster_path}` : '';
  const rating = item.vote_average?.toFixed(1) || '—';
  const year = (item.release_date || item.first_air_date || '').slice(0, 4);

  const el = document.createElement('div');
  el.className = 'card';
  el.onclick = () => openDetail(item, type);

  if (poster) {
    el.innerHTML = `
      <img src="${poster}" alt="${esc(name)}" loading="lazy" />
      <div class="card-overlay">
        <div class="card-play-icon">
          <svg viewBox="0 0 24 24" fill="#000" width="18" height="18"><polygon points="5,3 19,12 5,21"/></svg>
        </div>
        <div class="card-title">${esc(name)}</div>
        <div class="card-meta">
          <span class="card-rating">⭐ ${rating}</span>
          <span>${year}</span>
        </div>
      </div>
    `;
  } else {
    el.innerHTML = `
      <div class="card-no-img">${type === 'tv' ? '📺' : '🎬'}</div>
      <div class="card-overlay">
        <div class="card-play-icon">
          <svg viewBox="0 0 24 24" fill="#000" width="18" height="18"><polygon points="5,3 19,12 5,21"/></svg>
        </div>
        <div class="card-title">${esc(name)}</div>
        <div class="card-meta">
          <span class="card-rating">⭐ ${rating}</span>
          <span>${year}</span>
        </div>
      </div>
    `;
  }
  return el;
}

// Grid cards (larger)
function createGridCard(item, type) {
  return createCard(item, type);
}

// ===== PAGES =====
function showPage(name) {
  state.prevPage = state.currentPage;
  state.currentPage = name;

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const target = document.getElementById(name + 'Page');
  if (target) target.classList.add('active');

  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
  const map = { home:'nlHome', movies:'nlMovies', series:'nlSeries', kids:'nlKids', disclaimer:'nlDisclaimer' };
  if (map[name]) document.getElementById(map[name])?.classList.add('active');

  const footer = document.getElementById('siteFooter');
  if (footer) footer.style.display = ['player','detail'].includes(name) ? 'none' : '';

  if (name === 'movies' && !document.getElementById('moviesGrid')?.children.length) loadMoviesCat();
  if (name === 'series' && !document.getElementById('seriesGrid')?.children.length) loadSeriesCat();
  if (name === 'kids' && !document.getElementById('kidsGrid')?.children.length) loadKidsGrid();

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function goBack() {
  showPage(state.prevPage || 'home');
}

// ===== MOVIES PAGE =====
let _moviesData = [];
async function loadMoviesCat() {
  state.moviePage = 1;
  _moviesData = [];
  const cat = document.getElementById('moviesCat')?.value || 'popular';
  const genre = document.getElementById('moviesGenre')?.value || '';
  const year = document.getElementById('moviesYear')?.value || '';
  state.movieCat = cat; state.movieGenre = genre; state.movieYear = year;

  const grid = document.getElementById('moviesGrid');
  grid.innerHTML = '<div style="grid-column:1/-1;display:flex;justify-content:center;padding:60px"><div class="pl-spinner"></div></div>';

  let url;
  if (genre) {
    url = `${BASE}/discover/movie?language=ar&with_genres=${genre}&sort_by=popularity.desc&page=1`;
    if (year) url += `&primary_release_year=${year}`;
  } else {
    url = `${BASE}/movie/${cat}?language=ar&page=1`;
    if (year) url = `${BASE}/discover/movie?language=ar&sort_by=popularity.desc&primary_release_year=${year}&page=1`;
  }

  // Load 4 pages at once for lots of content
  grid.innerHTML = '';
  for (let p = 1; p <= 4; p++) {
    const pageUrl = url.replace('page=1', `page=${p}`);
    fetchJSON(pageUrl).then(data => {
      const items = data?.results || [];
      _moviesData.push(...items);
      items.forEach(item => grid.appendChild(createGridCard(item, 'movie')));
    }).catch(() => {});
  }
  state.moviePage = 4;
}

async function loadMoreMovies() {
  state.moviePage++;
  const cat = state.movieCat;
  const genre = state.movieGenre;
  const year = state.movieYear;
  const grid = document.getElementById('moviesGrid');
  const btn = document.getElementById('moviesMore');
  btn.textContent = 'جارٍ التحميل...';

  let url = genre
    ? `${BASE}/discover/movie?language=ar&with_genres=${genre}&sort_by=popularity.desc&page=${state.moviePage}`
    : `${BASE}/movie/${cat}?language=ar&page=${state.moviePage}`;

  const data = await fetchJSON(url);
  const items = data?.results || [];
  items.forEach(item => grid.appendChild(createGridCard(item, 'movie')));
  btn.textContent = 'تحميل المزيد ↓';
}

// ===== SERIES PAGE =====
async function loadSeriesCat() {
  state.seriesPage = 1;
  const cat = document.getElementById('seriesCat')?.value || 'popular';
  const genre = document.getElementById('seriesGenre')?.value || '';
  state.seriesCat = cat; state.seriesGenre = genre;

  const grid = document.getElementById('seriesGrid');
  grid.innerHTML = '';

  let url = genre
    ? `${BASE}/discover/tv?language=ar&with_genres=${genre}&sort_by=popularity.desc&page=1`
    : `${BASE}/tv/${cat}?language=ar&page=1`;

  for (let p = 1; p <= 4; p++) {
    const pageUrl = url.replace('page=1', `page=${p}`);
    fetchJSON(pageUrl).then(data => {
      (data?.results || []).forEach(item => grid.appendChild(createGridCard(item, 'tv')));
    }).catch(() => {});
  }
  state.seriesPage = 4;
}

async function loadMoreSeries() {
  state.seriesPage++;
  const cat = state.seriesCat;
  const genre = state.seriesGenre;
  const grid = document.getElementById('seriesGrid');
  const btn = document.getElementById('seriesMore');
  btn.textContent = 'جارٍ التحميل...';

  let url = genre
    ? `${BASE}/discover/tv?language=ar&with_genres=${genre}&sort_by=popularity.desc&page=${state.seriesPage}`
    : `${BASE}/tv/${cat}?language=ar&page=${state.seriesPage}`;

  const data = await fetchJSON(url);
  (data?.results || []).forEach(item => grid.appendChild(createGridCard(item, 'tv')));
  btn.textContent = 'تحميل المزيد ↓';
}

// ===== KIDS =====
async function loadKidsGrid() {
  const grid = document.getElementById('kidsGrid');
  if (!grid) return;
  grid.innerHTML = '';

  const urls = [
    `${BASE}/discover/movie?language=ar&with_genres=16&sort_by=popularity.desc&page=1`,
    `${BASE}/discover/movie?language=ar&with_genres=10751&sort_by=popularity.desc&page=1`,
    `${BASE}/discover/tv?language=ar&with_genres=10762&sort_by=popularity.desc&page=1`,
    `${BASE}/discover/movie?language=ar&with_genres=16&sort_by=popularity.desc&page=2`,
    `${BASE}/discover/tv?language=ar&with_genres=16&sort_by=popularity.desc&page=1`,
    `${BASE}/discover/movie?language=ar&with_genres=10751&sort_by=popularity.desc&page=2`,
  ];

  for (const url of urls) {
    fetchJSON(url).then(data => {
      (data?.results || []).forEach(item => {
        const card = createGridCard(item, item.title ? 'movie' : 'tv');
        grid.appendChild(card);
      });
    }).catch(() => {});
    await sleep(100);
  }
}

async function searchKids(q) {
  const grid = document.getElementById('kidsGrid');
  if (!q || q.length < 2) { loadKidsGrid(); return; }

  grid.innerHTML = '';
  const data = await fetchJSON(`${BASE}/search/multi?language=ar&query=${encodeURIComponent(q)}&include_adult=false`);
  (data?.results || []).forEach(item => {
    const type = item.media_type === 'tv' ? 'tv' : 'movie';
    grid.appendChild(createGridCard(item, type));
  });
}

// Child Lock
let _lockTaps = 0, _lockTimer = null;
function toggleChildLock() {
  state.childLocked = !state.childLocked;
  const overlay = document.getElementById('childLockOverlay');
  const btn = document.getElementById('childLockBtn');
  const icon = document.getElementById('lockIcon');
  if (state.childLocked) {
    overlay.classList.remove('hidden');
    btn.classList.add('active');
    btn.innerHTML = '🔒 الشاشة مقفولة';
    _lockTaps = 0;
    updateLockDots();
  } else {
    overlay.classList.add('hidden');
    btn.classList.remove('active');
    btn.innerHTML = '<span id="lockIcon">🔓</span> قفل الشاشة';
  }
}

function handleLockTap() {
  _lockTaps++;
  updateLockDots();
  clearTimeout(_lockTimer);
  _lockTimer = setTimeout(() => { _lockTaps = 0; updateLockDots(); }, 3000);
  if (_lockTaps >= 5) {
    _lockTaps = 0;
    state.childLocked = false;
    document.getElementById('childLockOverlay').classList.add('hidden');
    const btn = document.getElementById('childLockBtn');
    btn.classList.remove('active');
    btn.innerHTML = '<span id="lockIcon">🔓</span> قفل الشاشة';
    showToast('تم فتح القفل ✓');
  }
}

function updateLockDots() {
  document.querySelectorAll('.lock-dots span').forEach((s, i) => {
    s.classList.toggle('lit', i < _lockTaps);
  });
}

// ===== SEARCH =====
function handleSearch(q) {
  const clear = document.getElementById('searchClear');
  if (clear) clear.classList.toggle('visible', q.length > 0);
  clearTimeout(state.searchTimer);
  if (!q || q.length < 2) {
    if (state.currentPage === 'search') showPage('home');
    return;
  }
  state.searchTimer = setTimeout(() => doSearch(q), 400);
}

function clearSearch() {
  document.getElementById('globalSearch').value = '';
  document.getElementById('searchClear')?.classList.remove('visible');
  if (state.currentPage === 'search') showPage('home');
}

async function doSearch(q) {
  showPage('search');
  document.getElementById('searchTitle').textContent = `🔍 نتائج: "${q}"`;
  const grid = document.getElementById('searchGrid');
  const empty = document.getElementById('searchEmpty');
  grid.innerHTML = '<div style="grid-column:1/-1;display:flex;justify-content:center;padding:60px"><div class="pl-spinner"></div></div>';
  empty.classList.add('hidden');

  const data = await fetchJSON(`${BASE}/search/multi?language=ar&query=${encodeURIComponent(q)}&include_adult=false&page=1`);
  const items = (data?.results || []).filter(i => i.media_type !== 'person');
  grid.innerHTML = '';

  if (!items.length) {
    empty.classList.remove('hidden');
    return;
  }
  items.forEach(item => {
    const type = item.media_type === 'tv' ? 'tv' : 'movie';
    grid.appendChild(createGridCard(item, type));
  });
}

// ===== SEE ALL =====
async function seeAll(url, title, type) {
  showPage('search');
  document.getElementById('searchTitle').textContent = title;
  const grid = document.getElementById('searchGrid');
  grid.innerHTML = '';

  for (let p = 1; p <= 6; p++) {
    const pUrl = url.includes('?') ? `${url}&page=${p}` : `${url}?page=${p}`;
    fetchJSON(pUrl).then(data => {
      (data?.results || []).forEach(item => grid.appendChild(createGridCard(item, type)));
    }).catch(() => {});
    await sleep(80);
  }
}

// ===== DETAIL PAGE =====
async function openDetail(item, type) {
  state.currentItem = item;
  state.currentType = type;
  showPage('detail');

  const bg = document.getElementById('detailBg');
  const body = document.getElementById('detailBody');

  const backdropUrl = item.backdrop_path ? `${IMG}original${item.backdrop_path}` : '';
  if (backdropUrl) bg.style.backgroundImage = `url(${backdropUrl})`;

  // Fetch full details
  const [details, credits] = await Promise.all([
    fetchJSON(`${BASE}/${type}/${item.id}?language=ar&append_to_response=videos`),
    fetchJSON(`${BASE}/${type}/${item.id}/credits?language=ar`),
  ]);

  const name = details.title || details.name || 'بدون عنوان';
  const poster = details.poster_path ? `${IMG}w342${details.poster_path}` : '';
  const overview = details.overview || item.overview || 'لا يوجد وصف متاح.';
  const rating = details.vote_average?.toFixed(1);
  const year = (details.release_date || details.first_air_date || '').slice(0, 4);
  const runtime = details.runtime ? `${details.runtime} دقيقة` : (details.episode_run_time?.[0] ? `${details.episode_run_time[0]} دق/حلقة` : '');
  const genres = (details.genres || []).map(g => `<span class="genre-tag">${g.name}</span>`).join('');
  const cast = (credits?.cast || []).slice(0, 12);
  const seasons = details.seasons || [];

  const castHTML = cast.length ? `
    <div class="detail-cast">
      <div class="cast-title">طاقم العمل</div>
      <div class="cast-strip">
        ${cast.map(c => `
          <div class="cast-card">
            <div class="cast-avatar">
              ${c.profile_path
                ? `<img src="${IMG}w185${c.profile_path}" alt="${esc(c.name)}" loading="lazy" />`
                : '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:28px">👤</div>'
              }
            </div>
            <div class="cast-name">${esc(c.name)}</div>
            <div class="cast-char">${esc(c.character || '')}</div>
          </div>
        `).join('')}
      </div>
    </div>
  ` : '';

  const seasonsHTML = seasons.length ? `
    <div class="detail-seasons">
      <div class="seasons-title">المواسم</div>
      <div class="season-tabs">
        ${seasons.filter(s => s.season_number > 0).map(s => `
          <button class="season-tab" onclick="selectSeason(${s.season_number},this)">${s.name}</button>
        `).join('')}
      </div>
    </div>
  ` : '';

  body.innerHTML = `
    <div class="detail-layout">
      <div>
        ${poster
          ? `<div class="detail-poster"><img src="${poster}" alt="${esc(name)}" /></div>`
          : `<div class="detail-poster-placeholder">${type === 'tv' ? '📺' : '🎬'}</div>`
        }
      </div>
      <div class="detail-info">
        <h1 class="detail-title">${esc(name)}</h1>
        <div class="detail-meta-row">
          <span class="detail-rating">⭐ ${rating}</span>
          <span>·</span><span>${year}</span>
          ${runtime ? `<span>·</span><span>${runtime}</span>` : ''}
          <span>·</span><span>${type === 'movie' ? 'فيلم' : 'مسلسل'}</span>
        </div>
        ${genres ? `<div class="detail-genres">${genres}</div>` : ''}
        <p class="detail-overview">${esc(overview)}</p>
        <div class="detail-actions">
          <button class="btn-play" onclick="openPlayer(state.currentItem, state.currentType)">
            <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><polygon points="5,3 19,12 5,21"/></svg>
            شاهد الآن
          </button>
        </div>
        ${seasonsHTML}
        ${castHTML}
      </div>
    </div>
  `;
}

function selectSeason(n, el) {
  document.querySelectorAll('.season-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
}

// ===== PLAYER =====
async function openPlayer(item, type) {
  state.currentItem = item;
  state.currentType = type;
  state.activeSeason = 1;
  state.activeEpisode = 1;
  state.activeSource = 0;
  showPage('player');

  const meta = document.getElementById('playerMeta');
  const name = item.title || item.name || 'بدون عنوان';
  const rating = item.vote_average?.toFixed(1);
  const year = (item.release_date || item.first_air_date || '').slice(0, 4);

  meta.innerHTML = `
    <div class="player-title">${esc(name)}</div>
    <div class="player-sub">⭐ ${rating} · ${year} · ${type === 'movie' ? 'فيلم' : 'مسلسل'}</div>
  `;

  // Sources
  renderSources(item.id, type, 1, 1);

  // If TV, load seasons
  if (type === 'tv') {
    const details = await fetchJSON(`${BASE}/tv/${item.id}?language=ar`);
    renderSeasonsEpisodes(item.id, details);
  } else {
    document.getElementById('playerSeasonsWrap').classList.add('hidden');
  }

  // Smart source selection
  smartLoadSource(item.id, type, 1, 1);

  // Related
  loadRelated(item.id, type);
}

function renderSources(id, type, s, e) {
  const wrap = document.getElementById('playerSourcesWrap');
  const isTv = type === 'tv';
  wrap.innerHTML = `
    <div class="sources-label">المصادر</div>
    <div class="sources-row">
      ${SOURCES.map((src, i) => `
        <button class="source-btn ${i === state.activeSource ? 'active' : ''}"
          onclick="selectSource(${i}, ${id}, '${type}', ${s}, ${e})">
          <span class="src-dot"></span>${src.label}
        </button>
      `).join('')}
    </div>
  `;
}

function selectSource(idx, id, type, s, e) {
  state.activeSource = idx;
  document.querySelectorAll('.source-btn').forEach((b, i) => b.classList.toggle('active', i === idx));
  const url = type === 'movie'
    ? SOURCES[idx].movie(id)
    : SOURCES[idx].tv(id, s, e);
  loadPlayerFrame(url);
}

function smartLoadSource(id, type, s, e) {
  // Start with best source and show loading
  const loading = document.getElementById('playerLoading');
  loading.classList.remove('hidden');

  const url = type === 'movie'
    ? SOURCES[0].movie(id)
    : SOURCES[0].tv(id, s, e);

  const frame = document.getElementById('playerFrame');
  frame.src = url;
  frame.onload = () => {
    setTimeout(() => loading.classList.add('hidden'), 800);
  };
}

function loadPlayerFrame(url) {
  const loading = document.getElementById('playerLoading');
  const frame = document.getElementById('playerFrame');
  loading.classList.remove('hidden');
  frame.src = 'about:blank';
  setTimeout(() => {
    frame.src = url;
    frame.onload = () => setTimeout(() => loading.classList.add('hidden'), 600);
  }, 100);
}

async function renderSeasonsEpisodes(id, details) {
  const wrap = document.getElementById('playerSeasonsWrap');
  wrap.classList.remove('hidden');
  const seasons = (details.seasons || []).filter(s => s.season_number > 0);
  if (!seasons.length) { wrap.classList.add('hidden'); return; }

  wrap.innerHTML = `
    <div class="ps-label">المواسم والحلقات</div>
    <div class="ps-seasons">
      ${seasons.map(s => `
        <button class="ps-btn ${s.season_number === 1 ? 'active' : ''}"
          onclick="selectPlayerSeason(${id}, ${s.season_number}, ${s.episode_count}, this)">
          م${s.season_number}
        </button>
      `).join('')}
    </div>
    <div class="ps-episodes" id="psEpisodes"></div>
  `;

  // Load episodes for season 1
  renderEpisodes(id, 1, seasons[0]?.episode_count || 20);
}

async function selectPlayerSeason(id, sn, epCount, el) {
  document.querySelectorAll('.ps-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  state.activeSeason = sn;
  state.activeEpisode = 1;
  renderEpisodes(id, sn, epCount);
  renderSources(id, 'tv', sn, 1);
  smartLoadSource(id, 'tv', sn, 1);
}

async function renderEpisodes(id, sn, fallbackCount) {
  const container = document.getElementById('psEpisodes');
  if (!container) return;
  container.innerHTML = '';

  let count = fallbackCount;
  try {
    const data = await fetchJSON(`${BASE}/tv/${id}/season/${sn}?language=ar`);
    count = data?.episodes?.length || fallbackCount;
  } catch(e) {}

  for (let ep = 1; ep <= Math.min(count, 100); ep++) {
    const btn = document.createElement('button');
    btn.className = `ep-btn ${ep === state.activeEpisode ? 'active' : ''}`;
    btn.textContent = `ح${ep}`;
    const epNum = ep;
    btn.onclick = () => {
      document.querySelectorAll('.ep-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.activeEpisode = epNum;
      renderSources(id, 'tv', state.activeSeason, epNum);
      smartLoadSource(id, 'tv', state.activeSeason, epNum);
    };
    container.appendChild(btn);
  }
}

async function loadRelated(id, type) {
  const wrap = document.getElementById('playerRelated');
  const data = await fetchJSON(`${BASE}/${type}/${id}/similar?language=ar&page=1`);
  const items = data?.results?.slice(0, 10) || [];
  if (!items.length) { wrap.innerHTML = ''; return; }

  wrap.innerHTML = `
    <div class="content-row">
      <div class="row-header"><div class="row-title">قد يعجبك أيضاً</div></div>
      <div class="cards-strip" id="relatedStrip"></div>
    </div>
  `;
  const strip = document.getElementById('relatedStrip');
  items.forEach(item => strip.appendChild(createCard(item, type)));
}

// ===== NAVBAR SCROLL =====
function handleScroll() {
  const nav = document.getElementById('navbar');
  if (window.scrollY > 40) nav.classList.add('solid');
  else nav.classList.remove('solid');
}

// ===== TOAST =====
function showToast(msg, dur = 2500) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  t.classList.add('show');
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.classList.add('hidden'), 300);
  }, dur);
}

// ===== UTILS =====
async function fetchJSON(url) {
  const res = await fetch(url, { headers: HEADERS });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function esc(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// XSS protection: sanitize any dynamic content
function sanitize(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}
